"""测试 services/session.py：会话管理

测试策略：
  - services/session.py 从 memory.py 导入 memory_create_session、set_session_role 等
  - 用 monkeypatch 打桩这些内部调用
"""

import pytest
from services.session import change_session_role, init_new_session


class TestInitNewSession:
    def test_init_calls_setup_functions(self, monkeypatch):
        calls = []

        def fake_set_session_role(uid, sid, r, s="默认"):
            calls.append(("set_session_role", uid, sid, r, s))

        def fake_memory_create_session(uid, sid, r, s="默认"):
            calls.append(("create_session", uid, sid, r, s))

        monkeypatch.setattr("services.session.set_session_role", fake_set_session_role)
        monkeypatch.setattr("services.session.memory_create_session", fake_memory_create_session)

        result = init_new_session("testuser", "sess-001", "律师")

        assert result["error"] is None
        assert ("create_session", "testuser", "sess-001", "律师", "默认") in calls

    def test_init_with_style(self, monkeypatch):
        calls = []

        def fake_memory_create_session(uid, sid, r, s="默认"):
            calls.append((r, s))

        monkeypatch.setattr("services.session.memory_create_session", fake_memory_create_session)
        monkeypatch.setattr("services.session.set_session_role", lambda *a, **kw: None)

        init_new_session("testuser", "sess-002", "医生", "严谨专业")
        assert ("医生", "严谨专业") in calls

    def test_init_invalid_role_returns_error(self, monkeypatch):
        monkeypatch.setattr("services.session.memory_create_session", lambda *a, **kw: None)
        result = init_new_session("testuser", "sess-003", "工程师")
        assert result["error"] is not None

    def test_init_empty_params_return_error(self):
        result = init_new_session("", "sess-004", "律师")
        assert result["error"] is not None

    def test_init_empty_role(self):
        result = init_new_session("testuser", "sess-005", "")
        assert result["error"] is not None


class TestChangeSessionRole:
    def test_change_role(self, monkeypatch):
        calls = []

        def fake_set_session_role(uid, sid, r, s="默认"):
            calls.append(("set", uid, sid, r, s))

        monkeypatch.setattr("services.session.set_session_role", fake_set_session_role)

        result = change_session_role("testuser", "sess-001", "医生")
        assert result["error"] is None
        set_calls = [c for c in calls if c[0] == "set"]
        assert len(set_calls) >= 1
        assert set_calls[-1][3] == "医生"

    def test_change_invalid_role(self, monkeypatch):
        monkeypatch.setattr("services.session.set_session_role", lambda *a, **kw: None)
        result = change_session_role("testuser", "sess-002", "黑客")
        assert result["error"] is not None

    def test_change_empty_user(self):
        result = change_session_role("", "sess-003", "律师")
        assert result["error"] is not None
