"""
测试 milvus_pool.py — Milvus 连接池管理模块

使用 unittest.mock 模拟 pymilvus，不依赖真实 Milvus 服务。
"""
import pytest
from unittest.mock import patch, MagicMock

# 在导入 milvus_pool 之前 mock pymilvus
import sys

_mock_pymilvus = MagicMock()
sys.modules["pymilvus"] = _mock_pymilvus

from milvus_pool import (
    init_milvus_connection,
    ensure_connected,
    get_cached_collection,
    has_cached_collection,
)


class TestInitMilvusConnection:
    """init_milvus_connection 测试。"""

    def test_success(self):
        """连接成功应返回 True。"""
        result = init_milvus_connection()
        assert result is True

    @patch("milvus_pool.connections.connect", side_effect=Exception("连接失败"))
    def test_failure(self, mock_connect):
        """连接失败应返回 False（不抛出异常）。"""
        result = init_milvus_connection()
        assert result is False


class TestEnsureConnected:
    """ensure_connected 测试。"""

    @patch("milvus_pool.connections.connect")
    def test_called_when_not_connected(self, mock_connect):
        """未连接时应调用 connect。"""
        ensure_connected()
        mock_connect.assert_called_once()

    @patch("milvus_pool.connections.connect", side_effect=Exception("连接失败"))
    def test_error_does_not_propagate(self, mock_connect):
        """连接失败时应捕获异常不抛出。"""
        ensure_connected()  # 不应抛出


class TestGetCachedCollection:
    """get_cached_collection 测试。"""

    @patch("milvus_pool.connections.connect")
    @patch("milvus_pool.Collection")
    def test_returns_collection(self, mock_collection_cls, mock_connect):
        """应返回 Collection 实例。"""
        mock_collection_cls.return_value = "mock_collection"
        result = get_cached_collection("test_collection")
        assert result == "mock_collection"
        mock_collection_cls.assert_called_once_with("test_collection")

    @patch("milvus_pool.connections.connect")
    @patch("milvus_pool.Collection")
    def test_cached_reuses_instance(self, mock_collection_cls, mock_connect):
        """相同 collection 名应返回缓存实例（只创建一次）。"""
        mock_collection_cls.return_value = "cached"
        result1 = get_cached_collection("dup_name")
        result2 = get_cached_collection("dup_name")
        assert result1 == result2
        assert mock_collection_cls.call_count == 1


class TestHasCachedCollection:
    """has_cached_collection 测试。"""

    @patch("milvus_pool.connections.connect")
    @patch("milvus_pool.utility.has_collection", return_value=True)
    def test_exists(self, mock_has, mock_connect):
        """collection 存在时返回 True。"""
        assert has_cached_collection("existing") is True

    @patch("milvus_pool.connections.connect")
    @patch("milvus_pool.utility.has_collection", return_value=False)
    def test_not_exists(self, mock_has, mock_connect):
        """collection 不存在时返回 False。"""
        assert has_cached_collection("nonexistent") is False
