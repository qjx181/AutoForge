"""测试 services/retrieval_cache.py：Redis 缓存层

测试策略：
- 在 import retrieval_cache 之前 mock redis 模块
- 验证缓存命中/未命中/失效的核心逻辑
- 验证 Redis 不可用时的降级行为
- 验证空结果不被缓存的优化策略
"""

import hashlib
import json
from unittest.mock import MagicMock, patch, call

import pytest

# ===== 在 import retrieval_cache 之前先 mock redis =====
redis_mock = MagicMock()
redis_mock.Redis = MagicMock(return_value=MagicMock())
redis_mock.RedisError = Exception  # 模拟 RedisError 基类
import sys
sys.modules["redis"] = redis_mock
sys.modules["redis.exceptions"] = MagicMock()
sys.modules["redis.exceptions"].RedisError = Exception

# ===== 现在 import 被测模块 =====
from services.retrieval_cache import (
    _build_cache_key,
    _get_client,
    get_cached_result,
    set_cached_result,
    invalidate_cache,
    _REDIS_TTL,
)


def _expected_key(query: str, role: str) -> str:
    """计算预期的缓存 key，与生产代码逻辑一致"""
    raw = f"retrieval:{role}:{query.strip().lower()}"
    return f"rag:cache:{hashlib.sha256(raw.encode()).hexdigest()}"


# =============================================================================
# _build_cache_key
# =============================================================================

class TestBuildCacheKey:
    def test_consistent_key(self):
        """相同 query+role 产生相同 key"""
        k1 = _build_cache_key("高血压", "医生")
        k2 = _build_cache_key("高血压", "医生")
        assert k1 == k2

    def test_case_insensitive_query(self):
        """query 大小写不敏感"""
        k1 = _build_cache_key("Hello World", "医生")
        k2 = _build_cache_key("hello world", "医生")
        assert k1 == k2

    def test_query_whitespace_trimmed(self):
        """query 首尾空格被修剪"""
        k1 = _build_cache_key("  高血压  ", "医生")
        k2 = _build_cache_key("高血压", "医生")
        assert k1 == k2

    def test_different_role_different_key(self):
        """不同 role 产生不同 key"""
        k1 = _build_cache_key("高血压", "医生")
        k2 = _build_cache_key("高血压", "律师")
        assert k1 != k2

    def test_prefix_format(self):
        """key 以 rag:cache: 开头"""
        key = _build_cache_key("test", "user")
        assert key.startswith("rag:cache:")
        # 前缀后面的部分应该是 64 字符的 SHA256 hex
        hex_part = key[len("rag:cache:"):]
        assert len(hex_part) == 64
        int(hex_part, 16)  # 确认是合法 hex


# =============================================================================
# _get_client
# =============================================================================

class TestGetClient:
    def test_returns_none_when_redis_unavailable(self, monkeypatch: pytest.MonkeyPatch):
        """Redis 不可用时返回 None"""
        # 清除模块级缓存
        monkeypatch.setattr("services.retrieval_cache._cache_client", None)
        monkeypatch.setattr("services.retrieval_cache._cache_available", False)
        # 让 Redis() 构造函数也抛出异常
        bad_redis = MagicMock(side_effect=Exception("Connection refused"))
        monkeypatch.setattr("services.retrieval_cache.redis.Redis", bad_redis)
        client = _get_client()
        assert client is None

    def test_does_not_reconnect_after_success(self, monkeypatch: pytest.MonkeyPatch):
        """首次成功连接后，再次调用不创建新连接"""
        monkeypatch.setattr("services.retrieval_cache._cache_client", None)
        monkeypatch.setattr("services.retrieval_cache._cache_available", False)

        real_redis = MagicMock()
        real_redis.ping = MagicMock(return_value=True)

        class FakeRedis:
            def __call__(self, *args, **kwargs):
                return real_redis

        monkeypatch.setattr("services.retrieval_cache.redis.Redis", FakeRedis())

        # 第一次调用
        client1 = _get_client()
        # 已缓存
        client2 = _get_client()
        assert client1 is client2


# =============================================================================
# get_cached_result
# =============================================================================

class TestGetCachedResult:
    def test_cache_miss_returns_none(self, monkeypatch: pytest.MonkeyPatch):
        """缓存未命中返回 None"""
        mock_client = MagicMock()
        mock_client.get.return_value = None
        monkeypatch.setattr("services.retrieval_cache._get_client", lambda: mock_client)

        result = get_cached_result("高血压", "医生")
        assert result is None

    def test_cache_hit_returns_7tuple(self, monkeypatch: pytest.MonkeyPatch):
        """缓存命中返回正确的 7 元组"""
        payload = {
            "context": "高血压的诊断标准...",
            "refs": [{"rank": 1, "title": "test"}],
            "retrieval_seconds": 0.15,
            "bm25_item_count": 10,
            "semantic_count": 5,
            "vector_count": 8,
            "best_score": 0.92,
        }
        mock_client = MagicMock()
        mock_client.get.return_value = json.dumps(payload)
        monkeypatch.setattr("services.retrieval_cache._get_client", lambda: mock_client)

        result = get_cached_result("高血压", "医生")
        assert isinstance(result, tuple)
        assert len(result) == 7
        ctx, refs, secs, bm25, sem, vec, score = result
        assert ctx == "高血压的诊断标准..."
        assert refs == [{"rank": 1, "title": "test"}]
        assert secs == 0.15
        assert bm25 == 10
        assert sem == 5
        assert vec == 8
        assert score == 0.92

    def test_none_client_returns_none(self, monkeypatch: pytest.MonkeyPatch):
        """Redis 不可用时返回 None（不崩溃）"""
        monkeypatch.setattr("services.retrieval_cache._get_client", lambda: None)
        result = get_cached_result("test", "user")
        assert result is None

    def test_malformed_json_returns_none(self, monkeypatch: pytest.MonkeyPatch):
        """损坏的 JSON 返回 None（不崩溃）"""
        mock_client = MagicMock()
        mock_client.get.return_value = "not valid json{{{"
        monkeypatch.setattr("services.retrieval_cache._get_client", lambda: mock_client)

        result = get_cached_result("test", "user")
        assert result is None

    def test_missing_fields_raises_key_error_or_returns_none(self, monkeypatch: pytest.MonkeyPatch):
        """缺少字段的 JSON 返回 None 而非崩溃"""
        mock_client = MagicMock()
        mock_client.get.return_value = json.dumps({"context": "only"})  # 缺少 refs 等字段
        monkeypatch.setattr("services.retrieval_cache._get_client", lambda: mock_client)

        # 应该返回 None 或崩溃，但不应该抛出未捕获异常
        try:
            result = get_cached_result("test", "user")
            assert result is not None, "缺少字段应返回 None 或异常"
        except (KeyError, TypeError):
            pass  # 也是可接受的行为——调用方应处理


# =============================================================================
# set_cached_result
# =============================================================================

class TestSetCachedResult:
    def test_cache_write_happens(self, monkeypatch: pytest.MonkeyPatch):
        """设置缓存会调用 Redis setex"""
        mock_client = MagicMock()
        monkeypatch.setattr("services.retrieval_cache._get_client", lambda: mock_client)

        result = ("高血压的诊断标准...", [{"rank": 1}], 0.15, 10, 5, 8, 0.92)
        set_cached_result("高血压", "医生", result)

        expected_key = "rag:cache:" + hashlib.sha256(
            "retrieval:医生:高血压".encode()
        ).hexdigest()

        # 验证 setex 被调用
        assert mock_client.setex.called
        call_args = mock_client.setex.call_args[0]
        assert call_args[0] == expected_key
        assert call_args[1] == _REDIS_TTL  # TTL
        # payload 应为 JSON 字符串
        payload = json.loads(call_args[2])
        assert payload["context"] == "高血压的诊断标准..."
        assert payload["best_score"] == 0.92

    def test_empty_context_not_cached(self, monkeypatch: pytest.MonkeyPatch):
        """空内容不被缓存"""
        mock_client = MagicMock()
        monkeypatch.setattr("services.retrieval_cache._get_client", lambda: mock_client)

        result = ("", [{"rank": 1}], 0.15, 10, 5, 8, 0.0)
        set_cached_result("empty", "user", result)

        assert not mock_client.setex.called, "不应缓存空内容"

    def test_none_client_does_not_write(self, monkeypatch: pytest.MonkeyPatch):
        """Redis 不可用时跳过写入"""
        mock_client = MagicMock()
        monkeypatch.setattr("services.retrieval_cache._get_client", lambda: None)

        result = ("some content", [], 0.1, 1, 0, 0, 0.5)
        set_cached_result("test", "user", result)
        # 不应崩溃
        assert True

    def test_redis_error_on_write_does_not_crash(self, monkeypatch: pytest.MonkeyPatch):
        """写入时 Redis 异常被静默处理"""
        mock_client = MagicMock()
        mock_client.setex.side_effect = Exception("OOM")
        monkeypatch.setattr("services.retrieval_cache._get_client", lambda: mock_client)

        result = ("some content", [], 0.1, 1, 0, 0, 0.5)
        set_cached_result("test", "user", result)
        # 不应崩溃
        assert True


# =============================================================================
# invalidate_cache
# =============================================================================

class TestInvalidateCache:
    def test_deletes_key(self, monkeypatch: pytest.MonkeyPatch):
        """失效操作删除对应的缓存 key"""
        mock_client = MagicMock()
        monkeypatch.setattr("services.retrieval_cache._get_client", lambda: mock_client)

        invalidate_cache("高血压", "医生")

        expected_key = "rag:cache:" + hashlib.sha256(
            "retrieval:医生:高血压".encode()
        ).hexdigest()
        mock_client.delete.assert_called_once_with(expected_key)

    def test_none_client_noop(self, monkeypatch: pytest.MonkeyPatch):
        """Redis 不可用时失效操作不做任何事"""
        mock_client = MagicMock()
        monkeypatch.setattr("services.retrieval_cache._get_client", lambda: None)

        invalidate_cache("test", "user")
        assert not mock_client.delete.called

    def test_redis_error_noop(self, monkeypatch: pytest.MonkeyPatch):
        """Redis 异常时失效操作不崩溃"""
        mock_client = MagicMock()
        mock_client.delete.side_effect = Exception("timeout")
        monkeypatch.setattr("services.retrieval_cache._get_client", lambda: mock_client)

        invalidate_cache("test", "user")
        # 不应崩溃
        assert True
