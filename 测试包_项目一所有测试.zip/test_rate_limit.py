"""
测试 middleware/rate_limit.py — TokenBucket 令牌桶限流器
"""
import pytest
from unittest.mock import patch

from middleware.rate_limit import TokenBucket, acquire_chat_slot, release_chat_slot


class TestTokenBucket:
    """TokenBucket 令牌桶限流器测试。"""

    def test_construct_with_capacity(self):
        """构造后桶内应有 capacity 个令牌。"""
        tb = TokenBucket(rate=10.0, capacity=20)
        assert tb.capacity == 20

    def test_acquire_normal(self):
        """正常消耗不超额时返回 True。"""
        with patch("time.monotonic", return_value=100.0):
            tb = TokenBucket(rate=10.0, capacity=20)
            assert tb.acquire(1) is True
            assert tb.acquire(5) is True

    def test_acquire_exact_capacity(self):
        """消耗全部令牌后返回 True，再次消耗返回 False。"""
        with patch("time.monotonic", return_value=100.0):
            tb = TokenBucket(rate=10.0, capacity=5)
            assert tb.acquire(5) is True
            # 桶空了
            assert tb.acquire(1) is False

    def test_acquire_exceed_capacity(self):
        """消耗超过容量时返回 False。"""
        with patch("time.monotonic", return_value=100.0):
            tb = TokenBucket(rate=10.0, capacity=5)
            assert tb.acquire(10) is False

    def test_refill_after_time(self):
        """经过一段时间后桶内令牌应自动恢复。"""
        with patch("time.monotonic", side_effect=[100.0, 100.0, 103.0]):
            tb = TokenBucket(rate=2.0, capacity=10)
            assert tb.acquire(10) is True  # 消耗全部
            assert tb.acquire(6) is True  # 3秒后理论恢复 6 个

    def test_refill_does_not_exceed_capacity(self):
        """恢复后不应超过容量上限。"""
        with patch("time.monotonic", side_effect=[100.0, 100.0, 2000.0]):
            tb = TokenBucket(rate=100.0, capacity=10)
            assert tb.acquire(10) is True  # 消耗全部
            assert tb.acquire(10) is True  # 1000秒后恢复，但不超过 10

    def test_burst_then_refill(self):
        """突发消耗后能正确恢复。"""
        # __post_init__(100.0) → acquire(8) → _refill(100.0) → tokens=2 → acquire(3) → _refill(100.0) → tokens=2 → False
        # → wait 2s → _refill(102.0) → tokens=2+2*2=6 → acquire(3) → True
        with patch("time.monotonic", side_effect=[100.0, 100.0, 100.0, 102.0]):
            tb = TokenBucket(rate=2.0, capacity=10)
            assert tb.acquire(8) is True
            assert tb.acquire(3) is False  # 仅剩 2 个，不够 3
            # 又过 2 秒 → 恢复 4 个，现有 6 个
            assert tb.acquire(3) is True

    def test_zero_rate_no_refill(self):
        """速率为 0 时消耗完不可恢复。"""
        with patch("time.monotonic", side_effect=[100.0, 100.0, 200.0]):
            tb = TokenBucket(rate=0.0, capacity=10)
            assert tb.acquire(10) is True
            assert tb.acquire(1) is False  # rate=0，永不恢复


class TestSemaphoreSync:
    """Semaphore 并发控制同步测试（不依赖 pytest-asyncio）。"""

    def test_acquire_release_pattern(self):
        """同步验证 Semaphore 的 acquire/release 基础模式。"""
        import asyncio

        sem = asyncio.Semaphore(2)
        # acquire 前可用槽位数 = 2
        assert sem._value == 2
        sem._value = 1  # 模拟消耗
        assert sem._value == 1
        sem._value += 1  # 模拟释放
        assert sem._value == 2
