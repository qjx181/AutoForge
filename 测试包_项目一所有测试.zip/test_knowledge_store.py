"""测试 services/knowledge_store.py：聊天知识库 Milvus 存储/检索模块

核心关注点：
1. 集合创建/获取逻辑（ensure_chat_knowledge_collection）
2. 存储聊天知识到 Milvus（save_chat_knowledge_to_milvus）
3. 从 Milvus 检索聊天知识（search_chat_knowledge）
4. 行->引用转换（_row_to_ref）
5. 异常容忍（Milvus 不可用、空输入、编码失败）
"""
import sys
from pathlib import Path
from unittest.mock import ANY, MagicMock, patch

import pytest

# ===== 在 import 任何项目模块前 mock 外部第三方包 =====
sys.modules["pymilvus"] = MagicMock()
sys.modules["pymilvus"].utility = MagicMock()
sys.modules["pymilvus"].Collection = MagicMock
sys.modules["pymilvus"].CollectionSchema = MagicMock
sys.modules["pymilvus"].DataType = MagicMock()
sys.modules["pymilvus"].FieldSchema = MagicMock

# mock milvus_pool
milvus_pool_mock = MagicMock()
milvus_pool_mock.ensure_connected = MagicMock(return_value=None)
sys.modules["milvus_pool"] = milvus_pool_mock

# ===== 导入待测模块 =====
from services.knowledge_store import (
    _row_to_ref,
    ensure_chat_knowledge_collection,
    save_chat_knowledge_to_milvus,
    search_chat_knowledge,
)


# ===== _row_to_ref 测试（纯函数，无外部依赖） =====


class TestRowToRef:
    """_row_to_ref 行→引用转换。"""

    def test_normal_row(self):
        """标准行应正确转换为 (item, score, source) 元组。"""
        row = {
            "id": "abc123",
            "query": "测试问题",
            "answer": "测试答案",
            "retrieved_context": "检索上下文",
            "created_at": "2026-05-18 12:00:00",
            "session_id": "sess001",
            "role": "律师",
            "style": "严谨专业",
        }
        item, score, source = _row_to_ref(row, 0.85)
        assert source == "chat_kb"
        assert score == 0.85
        assert item["id"] == "abc123"
        assert item["title"] == "测试问题"
        assert item["content"] == "测试答案"
        assert item["page"] == "2026-05-18 12:00:00"
        assert item["source_file"] == "sess001"

    def test_missing_answer_falls_back_to_context(self):
        """answer 缺失时应 fallback 到 retrieved_context。"""
        row = {"answer": None, "retrieved_context": "回退内容", "query": "问题"}
        item, _, _ = _row_to_ref(row, 0.5)
        assert item["content"] == "回退内容"

    def test_missing_all_falls_back_to_query(self):
        """answer 和 retrieved_context 都缺失时 fallback 到 query。"""
        row = {"answer": "", "retrieved_context": "", "query": "仅问题"}
        item, _, _ = _row_to_ref(row, 0.5)
        assert "仅问题" in item["content"]

    def test_empty_row_uses_defaults(self):
        """空行应使用各字段的默认值。"""
        row = {}
        item, score, source = _row_to_ref(row, 0.0)
        assert score == 0.0
        assert item["id"] == ""
        assert item["title"] == "聊天知识"
        assert item["url"] == ""


class TestEnsureChatKnowledgeCollection:
    """ensure_chat_knowledge_collection 集合创建/获取。"""

    @patch("services.knowledge_store.utility")
    @patch("services.knowledge_store.get_cached_collection")
    def test_existing_returns_cached(self, mock_get_cached, mock_utility):
        """集合已存在时应返回缓存的集合对象。"""
        mock_utility.has_collection.return_value = True
        cached = MagicMock()
        mock_get_cached.return_value = cached

        result = ensure_chat_knowledge_collection(dim=768)
        assert result is cached
        mock_utility.has_collection.assert_called_once_with("chat_knowledge_base")

    @patch("services.knowledge_store.utility")
    @patch("services.knowledge_store.Collection")
    def test_new_collection_creates_and_indexes(self, mock_collection_cls, mock_utility):
        """集合不存在时应创建新集合并建立索引。"""
        mock_utility.has_collection.return_value = False
        col_instance = MagicMock()
        mock_collection_cls.return_value = col_instance

        result = ensure_chat_knowledge_collection(dim=384)

        # 验证创建了 Collection 实例
        mock_collection_cls.assert_called_once()
        args, kwargs = mock_collection_cls.call_args
        assert args[0] == "chat_knowledge_base"
        assert "schema" in kwargs

        # 验证建立了索引
        col_instance.create_index.assert_called_once()
        index_params = col_instance.create_index.call_args[1]
        assert index_params["field_name"] == "embedding"
        assert index_params["index_params"]["metric_type"] == "COSINE"

        assert result is col_instance

    @patch("services.knowledge_store.utility")
    @patch("services.knowledge_store.get_cached_collection")
    def test_collection_ensures_connection(self, mock_get_cached, mock_utility):
        """每次调用都应先确保连接。"""
        with patch("services.knowledge_store.ensure_connected") as mock_connect:
            mock_utility.has_collection.return_value = True
            mock_get_cached.return_value = MagicMock()
            ensure_chat_knowledge_collection(dim=256)
            mock_connect.assert_called_once()


class TestSaveChatKnowledge:
    """save_chat_knowledge_to_milvus 存储聊天知识。"""

    @patch("services.knowledge_store.ensure_chat_knowledge_collection")
    def test_normal_save_returns_one(self, mock_ensure):
        """正常保存应返回 1（1 条写入）。"""
        collection = MagicMock()
        mock_ensure.return_value = collection
        model = MagicMock()
        model.encode.return_value = [[0.1] * 384]

        result = save_chat_knowledge_to_milvus(
            model,
            user_id="u1",
            session_id="s1",
            role="律师",
            style="严谨专业",
            query="测试问题",
            retrieved_context="检索结果",
            answer="最终回答",
            references=[{"title": "doc1"}],
        )
        assert result == 1
        # 验证 encode 被调用
        model.encode.assert_called_once()
        # 验证 insert 被调用
        collection.insert.assert_called_once()
        collection.flush.assert_called_once()

    @patch("services.knowledge_store.ensure_chat_knowledge_collection")
    def test_empty_text_returns_zero(self, mock_ensure):
        """输入全是空字符串时应返回 0。"""
        result = save_chat_knowledge_to_milvus(
            MagicMock(),
            user_id="u1",
            session_id="s1",
            role="律师",
            style="默认",
            query="",
            retrieved_context="",
            answer="",
        )
        assert result == 0
        mock_ensure.assert_not_called()

    @patch("services.knowledge_store.ensure_chat_knowledge_collection")
    def test_none_references_handled(self, mock_ensure):
        """references=None 不应引发异常。"""
        collection = MagicMock()
        mock_ensure.return_value = collection
        model = MagicMock()
        model.encode.return_value = [[0.2] * 384]

        result = save_chat_knowledge_to_milvus(
            model,
            user_id="u2",
            session_id="s2",
            role="医生",
            style="温和耐心",
            query="头痛怎么办",
            retrieved_context="医典内容",
            answer="建议休息",
            references=None,
        )
        assert result == 1
        # references=None → json.dumps([])
        insert_args = collection.insert.call_args[0][0]
        assert insert_args[0]["references_json"] == "[]"

    @patch("services.knowledge_store.ensure_chat_knowledge_collection")
    def test_collection_load_exception_tolerated(self, mock_ensure):
        """collection.load() 引发异常不应阻止保存。"""
        collection = MagicMock()
        collection.load.side_effect = RuntimeError("load failed")
        mock_ensure.return_value = collection
        model = MagicMock()
        model.encode.return_value = [[0.3] * 384]

        result = save_chat_knowledge_to_milvus(
            model,
            user_id="u3",
            session_id="s3",
            role="律师",
            style="简洁干练",
            query="合同纠纷",
            retrieved_context="合同法条文",
            answer="需要查看合同",
        )
        assert result == 1  # load 异常被 try/except 捕获

    @patch("services.knowledge_store.ensure_chat_knowledge_collection")
    def test_encoding_exception_returns_zero(self, mock_ensure):
        """模型编码失败时应返回 0。"""
        model = MagicMock()
        model.encode.side_effect = RuntimeError("OOM")

        result = save_chat_knowledge_to_milvus(
            model,
            user_id="u4",
            session_id="s4",
            role="医生",
            style="默认",
            query="发烧怎么办",
            retrieved_context="医学知识",
            answer="多喝水",
        )
        assert result == 0  # 最外层 try/except 捕获

    @patch("services.knowledge_store.ensure_chat_knowledge_collection")
    def test_truncates_long_fields(self, mock_ensure):
        """超长字段应按 schema 限制被截断。"""
        collection = MagicMock()
        mock_ensure.return_value = collection
        model = MagicMock()
        model.encode.return_value = [[0.4] * 384]

        long_user_id = "u" * 300
        long_query = "查询" * 3000
        result = save_chat_knowledge_to_milvus(
            model,
            user_id=long_user_id,
            session_id="s5",
            role="律师",
            style="严谨专业",
            query=long_query,
            retrieved_context="ctx",
            answer="ans",
        )
        assert result == 1
        insert_row = collection.insert.call_args[0][0][0]
        assert len(insert_row["user_id"]) <= 128
        assert len(insert_row["query"]) <= 4096

    @patch("services.knowledge_store.ensure_chat_knowledge_collection")
    def test_has_created_at_timestamp(self, mock_ensure):
        """写入的行应有 created_at 时间戳。"""
        collection = MagicMock()
        mock_ensure.return_value = collection
        model = MagicMock()
        model.encode.return_value = [[0.5] * 384]

        save_chat_knowledge_to_milvus(
            model,
            user_id="u6",
            session_id="s6",
            role="律师",
            style="默认",
            query="继承法",
            retrieved_context="法条",
            answer="继承顺序...",
        )
        row = collection.insert.call_args[0][0][0]
        assert "created_at" in row
        assert "2026" in row["created_at"]  # 应包含当前年份


class TestSearchChatKnowledge:
    """search_chat_knowledge 检索聊天知识。"""

    @patch("services.knowledge_store.utility")
    @patch("services.knowledge_store.get_cached_collection")
    def test_empty_query_returns_empty(self, mock_get_cached, mock_utility):
        """空查询应直接返回 []。"""
        result = search_chat_knowledge("", MagicMock())
        assert result == []
        mock_get_cached.assert_not_called()

    @patch("services.knowledge_store.utility")
    @patch("services.knowledge_store.get_cached_collection")
    def test_whitespace_query_returns_empty(self, mock_get_cached, mock_utility):
        """全空格查询应直接返回 []。"""
        result = search_chat_knowledge("   ", MagicMock())
        assert result == []
        mock_get_cached.assert_not_called()

    @patch("services.knowledge_store.utility")
    @patch("services.knowledge_store.get_cached_collection")
    def test_no_collection_returns_empty(self, mock_get_cached, mock_utility):
        """集合不存在时应返回 []。"""
        mock_utility.has_collection.return_value = False

        result = search_chat_knowledge("测试问题", MagicMock())
        assert result == []
        mock_get_cached.assert_not_called()

    @patch("services.knowledge_store.utility")
    @patch("services.knowledge_store.get_cached_collection")
    def test_search_returns_transformed_hits(self, mock_get_cached, mock_utility):
        """搜索应返回 transform 后的结果列表。"""
        mock_utility.has_collection.return_value = True
        collection = MagicMock()
        mock_get_cached.return_value = collection

        # 构造 mock 搜索结果
        hit1 = MagicMock()
        hit1.score = 0.92
        hit1.entity.get.side_effect = lambda k, d="": {
            "query": "问题1",
            "retrieved_context": "上下文1",
            "answer": "答案1",
            "created_at": "2026-01-01",
            "session_id": "s1",
            "role": "律师",
            "style": "严谨专业",
        }.get(k, d)
        # entity.id 通过 getattr
        type(hit1.entity).id = MagicMock(return_value="id1")

        search_result = MagicMock()
        search_result.__getitem__.return_value = [hit1]
        collection.search.return_value = [search_result]

        model = MagicMock()
        model.encode.return_value = [MagicMock()]
        type(model.encode.return_value[0]).tolist = MagicMock(return_value=[0.1] * 384)

        results = search_chat_knowledge("测试问题", model, top_k=5)
        assert len(results) == 1
        item, score, source = results[0]
        assert source == "chat_kb"
        assert score == 0.92
        assert item["title"] == "问题1"
        assert item["content"] == "答案1"

    @patch("services.knowledge_store.utility")
    @patch("services.knowledge_store.get_cached_collection")
    def test_search_exception_returns_empty(self, mock_get_cached, mock_utility):
        """搜索异常时应返回 []。"""
        mock_utility.has_collection.return_value = True
        collection = MagicMock()
        collection.search.side_effect = RuntimeError("search timeout")
        mock_get_cached.return_value = collection

        model = MagicMock()
        model.encode.return_value = [MagicMock()]
        type(model.encode.return_value[0]).tolist = MagicMock(return_value=[0.1] * 384)

        results = search_chat_knowledge("测试问题", model)
        assert results == []

    @patch("services.knowledge_store.utility")
    @patch("services.knowledge_store.get_cached_collection")
    def test_no_hits_returns_empty(self, mock_get_cached, mock_utility):
        """搜索无命中时返回 []。"""
        mock_utility.has_collection.return_value = True
        collection = MagicMock()
        empty_result = MagicMock()
        empty_result.__getitem__.return_value = []
        collection.search.return_value = [empty_result]
        mock_get_cached.return_value = collection

        model = MagicMock()
        model.encode.return_value = [MagicMock()]
        type(model.encode.return_value[0]).tolist = MagicMock(return_value=[0.1] * 384)

        results = search_chat_knowledge("测试问题", model)
        assert results == []
