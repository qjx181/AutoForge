"""测试 routes/chat.py：聊天核心路由

测试策略：
  - 创建最小化 FastAPI 应用，mock 掉外部依赖
  - 测试正常流式(200)、限流(429)、并发超时(503)
  - 注意：StreamingResponse 内部的异常不能通过 HTTPException 抛出
    （response already started），所以 400/401 由 stream_chat_response
    内部以 SSE event: error 形式返回，此处不测试
"""

import sys
from unittest.mock import AsyncMock, MagicMock, patch

sys.modules["sentence_transformers"] = MagicMock()
sys.modules["sentence_transformers.SentenceTransformer"] = MagicMock()

from fastapi import FastAPI
from fastapi.testclient import TestClient

PROJ_PATH = "/mnt/c/Users/qjx/Desktop/agent-自进化版/项目一cursor版本/在线部分"
if PROJ_PATH not in sys.path:
    sys.path.insert(0, PROJ_PATH)

mock_retrieval = MagicMock()
mock_retrieval.build_context_sync.return_value = ("context", [], 0.1, 0, 0, 0, 0.0)
sys.modules["services.retrieval"] = mock_retrieval

mock_chat_service = MagicMock()
async def fake_stream(*args, **kwargs):
    yield "event: meta\ndata: {}\n\n".encode("utf-8")
    yield "data: chunk\n\n".encode("utf-8")
    yield "event: done\ndata: answer\n\n".encode("utf-8")
mock_chat_service.stream_chat_response = fake_stream
sys.modules["services.chat_service"] = mock_chat_service

from routes.chat import router as chat_router

app = FastAPI()
app.include_router(chat_router)
client = TestClient(app)


class TestChatRoute:
    @patch("routes.chat.CHAT_RATE_LIMITER")
    @patch("routes.chat.acquire_chat_slot", new_callable=AsyncMock)
    @patch("routes.chat.release_chat_slot")
    def test_chat_normal_flow(self, mock_release, mock_acquire, mock_limiter):
        mock_limiter.acquire.return_value = True
        mock_acquire.return_value = True

        resp = client.post("/chat", json={
            "session_id": "sess-001",
            "query": "你好",
            "role": "律师",
        })
        assert resp.status_code == 200
        assert "text/event-stream" in resp.headers["content-type"]

    @patch("routes.chat.CHAT_RATE_LIMITER")
    def test_rate_limit_exceeded(self, mock_limiter):
        mock_limiter.acquire.return_value = False

        resp = client.post("/chat", json={
            "session_id": "sess-001",
            "query": "你好",
        })
        assert resp.status_code == 429
        assert "请求过于频繁" in resp.text

    @patch("routes.chat.CHAT_RATE_LIMITER")
    @patch("routes.chat.acquire_chat_slot", new_callable=AsyncMock)
    def test_concurrency_timeout(self, mock_acquire, mock_limiter):
        mock_limiter.acquire.return_value = True
        mock_acquire.return_value = False

        resp = client.post("/chat", json={
            "session_id": "sess-001",
            "query": "测试",
        })
        assert resp.status_code == 503
        assert "系统繁忙" in resp.text
