"""测试 routes/auth.py：登录/注册/鉴权路由（独立app，不依赖sentence-transformers）

测试策略：
  - 创建最小化 FastAPI 应用，只挂载 auth 路由
  - conftest.py 已设置 AUTH_BACKEND=sqlite
  - 测试完整流程：注册 → 登录 → 获取用户信息 → 登出
"""

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

# 只导入 auth 相关模块，不触发 main.py 的完整依赖链
import os
os.environ["AUTH_BACKEND"] = "sqlite"

from routes.auth import router as auth_router

# 初始化数据库（auth.py 不会自动调用 init_db）
from auth import init_db
init_db()

app = FastAPI()
app.include_router(auth_router)

client = TestClient(app)


class TestRegister:
    def test_register_new_user(self):
        # 使用唯一用户名避免跨测试 DB 冲突
        import time
        username = f"test_reg_{int(time.time())}"
        resp = client.post("/auth/register", json={
            "username": username,
            "password": "TestPass123!",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["username"] == username
        assert "token" in data

    def test_register_duplicate_user(self):
        client.post("/auth/register", json={
            "username": "test_dup_user",
            "password": "Pass123!",
        })
        resp = client.post("/auth/register", json={
            "username": "test_dup_user",
            "password": "AnotherPass1!",
        })
        assert resp.status_code == 400

    def test_register_empty_username(self):
        resp = client.post("/auth/register", json={
            "username": "",
            "password": "TestPass123!",
        })
        assert resp.status_code in (400, 422)

    def test_register_short_password(self):
        resp = client.post("/auth/register", json={
            "username": "test_short_pw",
            "password": "12",
        })
        assert resp.status_code in (400, 422)


class TestLogin:
    @pytest.fixture(autouse=True)
    def _register_first(self):
        client.post("/auth/register", json={
            "username": "test_login_ok",
            "password": "LoginPass1!",
        })

    def test_login_success(self):
        resp = client.post("/auth/login", json={
            "username": "test_login_ok",
            "password": "LoginPass1!",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["username"] == "test_login_ok"
        assert len(data.get("token", "")) > 10

    def test_login_wrong_password(self):
        resp = client.post("/auth/login", json={
            "username": "test_login_ok",
            "password": "WrongPass1!",
        })
        assert resp.status_code == 400

    def test_login_nonexistent_user(self):
        resp = client.post("/auth/login", json={
            "username": "no_such_user_xyz",
            "password": "SomePass1!",
        })
        assert resp.status_code == 400

    def test_login_returns_cookie(self):
        resp = client.post("/auth/login", json={
            "username": "test_login_ok",
            "password": "LoginPass1!",
        })
        assert "access_token" in resp.cookies or "set-cookie" in resp.headers


class TestMe:
    @pytest.fixture(autouse=True)
    def _register_and_login(self):
        client.post("/auth/register", json={
            "username": "test_me_user",
            "password": "MePass123!",
        })
        self.token = client.post("/auth/login", json={
            "username": "test_me_user",
            "password": "MePass123!",
        }).json().get("token", "")

    def test_me_with_token(self):
        resp = client.get("/auth/me", headers={"Authorization": f"Bearer {self.token}"})
        assert resp.status_code == 200
        assert resp.json().get("username") == "test_me_user"

    def test_me_without_token(self):
        # 清除任何残留 cookie
        client.cookies.clear()
        resp = client.get("/auth/me")
        assert resp.status_code == 401


class TestLogout:
    def test_logout(self):
        resp = client.post("/auth/logout")
        assert resp.status_code == 200
